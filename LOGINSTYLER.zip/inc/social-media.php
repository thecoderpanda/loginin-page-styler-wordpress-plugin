<style>
.wlpd_social_media{
	  margin: 14px 0px;
  margin-bottom: 9px;
}
</style>

<div class="wlpd_social_media">
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.4&appId=166144553594684";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<div class="fb-like" data-href="https://www.facebook.com/pages/WPChandra-To-Start-for-Web-Development/325741047605388" data-layout="button_count" data-action="like" data-show-faces="false" data-share="false"></div>

</div>