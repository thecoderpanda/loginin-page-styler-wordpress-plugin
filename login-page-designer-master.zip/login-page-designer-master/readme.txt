=== Login Page Designer ===
Contributors: chandrakeshkumar,chandgiri67,wp-chandra
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=2V34FUDP29MLC
Tags: custom login, customize login, login page custom,login form, form, login, login page, admin login, admin, administration, ads adsense, advertising, affiliate, AJAX, amazon, analytics, api, audio, authentication, author, automatic, bbPress, blog, bookmark, bookmarks, buddypress, button, calendar, captcha, categories, category, Chat, cms, code, comment, comments, contact, contact form, content, counter, CSS ,custom, custom post type, dashboard, database, Digg, e-commerce, ecommerce ,edit ,editor, email, embed, event, events, Facebook, feed ,filter ,flash ,flickr ,form ,Formatting ,forms, free gallery, google, google maps, google, plus, html, html5 ,image, images, import, integration, iphone, javascript, jquery, language, lightbox, Like, link, linkedin, links, list, login, mail, map, maps, marketing, media, menu, meta, mobile, multisite, music, navigation, network, News, newsletter, notification, page, pages, password, payment, paypal, performance, photo, photos, php, picture, pictures, pinterest, plugin, plugins, popup, Post, posts, profile, random, redirect, registration ,responsive, rss, search, security, seo, Share, sharing, shop, shortcode, shortcodes, sidebar, simple, slider, slideshow, social, social media, spam, statistics, stats, store, tag, tags, Taxonomy, template, text, theme, themes, thumbnail, thumbnails, TinyMCE, title, tracking, tweet, twitter, upload, url, user, users, video, widget, widgets, woocommerce, wordpress, wpmu, xml, yahoo, youtube,chand, chand giri, chandrakesh, chandrakeshkumar, kumar, giri,chandra,wpchandra,wpchandra.com,wp-chandra,chandu,wordpress plugin,wordpress theme,google,google plugin,flicker,fb,custom login, login form, form, login styler,style,css,widget, post, plugin,image,twitter,like,google plus, shortcode,shortcodes, customize,page,comments,comment,sidebar,login page,logo, auto user registration, auto-login, autologin, comments, Facebook, Facebook Login, google, google apps, Google Login, google openidconnect, google social login, linkedin, linkedin login, login widget, login with facebook, login with google, login with linkedin, login with openid connect, login with salesforce, oauth, oauth login, OpenID Connect, openid connect sso, salesforce, salesforce login, salesforce openid connect, single sign-on, social connect, social login, social network login, social sharing, social sharing widget, sso, user auto register, widget login, admin, branding, custom login, custom login pro, customization, customizer, error, login, login customizer, login error, login logo, login page, customisation, customise, customization, customize, additional html, brand, brand login, custom login, customize, foolproof, inject css, login, login page, login redirect, login widget, multisite, own css, own look,  admin, admin custom login, admin login, admin login form, admin login page, background, background slideshow, branding, captcha, CSS, custom login, custom login page, custom login plugin, custom login pro, custom logo, customization, customize, customize wordpress login form, customizer, error, Facebook, form style, google plug, html, image, jquery, jquery form, linkedin, log in, login, login error, login form, login form plugin, logo, ogin page, plugin, role, security login, sideshow, social connect, social form, social share, style log in, style login, subscriber, themes, twitter, wordpress admin login, wordpress login, wp login form, wp-login
Requires at least: 3.4
Tested up to: 4.2.3  
Stable tag:3.1.5
License:GPLv2 
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Login page designer provides you to easy way to customize the appearance of the wordPress login page with many options.

==Description==
Login page designer provides you to easy way to customize the appearance of the wordPress login page with many options. Login Page Designer plugin have many option for customizing login page.
You can easy way to setting & install this plugin.

<strong>Features</strong>

* Plugin on or off.
* Change Logo Title.
* Hide Logo
* Hide Lost Password Link
* Hide Back to Link
* Disable Shake Effect
* Check Remember Me
* Change Login Redirect
* Change Logo Width
* Change Logo Height
* Change Logo Link
* Form Margin Top
* Form Label Font Size
* Form Label Color
* Form Label Font Style
* Logo upload button.
* Login Body background image upload button.
* Login Form Background color.
* Login Form Label fonts.
* Login Form border width.
* Login Form border color.
* Login Form border style.
* Login Form textbox border size.
* Login Form textbox border color.
* Login Form textbox border color.
* Login Form textbox border style.
* Login Form textbox border radius.
* Login Form textbox hover border size.
* Login Form textbox hover border color.
* Login Form textbox hover border color.
* Login Form textbox hover border style.
* Login Form Button border size.
* Login Form Button border color.
* Login Form Button border color.
* Login Form Button border style.
* Login Form Button border radius.
* Login Form Button hover border size.
* Login Form Button hover border color.
* Login Form Button hover border color.
* Login Form Button hover border style.
* And so more coming soon.


== Installation ==
Follow these steps to install this plugin

e.g.

1. Extract the zip file and just drop the contents in the wp-content/plugins/ directory of your WordPress installation and then activate the Plugin from Plugins page.
2. Now click on "Login Page Designer" menu in left sidebar.
3. Now show settings page.
4. Enjoy it!

== Frequently Asked Questions ==
There are no FAQ just yet

== Screenshots ==

1. Display Settings part-1
2. Display Settings part-2
3. Logo Settings
4. Form Settings
5. Login Form Display Settings
6. Submit Button setting
7. Textbox Settings
8. Login Page with background image
9. Login page with background color & logo
10. Login page blue background color & logo
11. Login form style1
12. Login form style2 
13. Login form style3
14. Login form style5
15. Login page with green background color
16. Login form green style
17. Login page with magenta background color
19. Login form style6
20. Login form style7
21. Login form style8
22. Login form style9
23. Login form style10
24. Login form style11
25. Login form style12


== Changelog ==

Version 1.0 released.

Version 1.1 released.